# Twitter Hate-Speech Mini-Project

## Environment
- Python 3.11 (tested on macOS)
- Install: `pip install -r requirements.txt`

## Data
We use the assignment’s Twitter hate-speech dataset. Splits included:
- `data/train_split.csv`, `data/val_split.csv`, `data/test_split.csv`

## How to Reproduce
1) Train (optional, models already evaluated):
   - `python scripts/train_svm.py`
   - `python scripts/train_bertweet.py` and `python scripts/train_bertweet_improved.py`
   - `python scripts/eval_twroberta_hate.py` and `python scripts/train_twroberta_hate_improved.py`
2) Collect + analyze:
   - `python scripts/collect_results.py`
   - `python scripts/statistical_tests.py`
   - `python scripts/error_analysis.py`
   - `python scripts/ablation_class_weights.py`
   - `python scripts/generate_figures.py`
3) Report:
   - See `Report.pdf` (figures/CSVs in `outputs/` and `results/`).

## Outputs
- `outputs/figures/*.pdf` (PR/ROC/pareto/confusions/calibration)
- `outputs/tables/*.csv` (summary, McNemar, bootstrap CI, ablation)
- `results/<model>/*` (metrics, predictions, efficiency)

## Notes
- We exclude heavy checkpoints/weights from the archive (repro code + metrics are included).
- Random seed: 42; split: 70/15/15.
