# utils/efficiency_tracker.py
import time
import numpy as np

class EfficiencyTracker:
    """Track efficiency metrics consistently across models"""
    
    def __init__(self, model_name):
        self.model_name = model_name
        self.train_start = None
        self.train_time = None
    
    def start_training(self):
        """Start tracking training time"""
        self.train_start = time.time()
        print("      Timer started")
    
    def end_training(self):
        """End tracking training time"""
        self.train_time = time.time() - self.train_start
        return {
            'train_time_seconds': float(self.train_time),
            'train_time_minutes': float(self.train_time / 60),
        }
    
    def measure_inference_latency(self, model, predict_fn, X_test, num_samples=100):
        """
        Measure inference latency (single sample)
        
        Args:
            model: The model object
            predict_fn: Function that takes (model, samples) and returns predictions
            X_test: Test data
            num_samples: Number of samples to measure
        """
        latencies = []
        n = min(num_samples, len(X_test))
        
        print(f"      Measuring latency on {n} samples...")
        for i in range(n):
            start = time.time()
            _ = predict_fn(model, [X_test.iloc[i] if hasattr(X_test, 'iloc') else X_test[i]])
            latencies.append(time.time() - start)
        
        return {
            'latency_p50_ms': float(np.percentile(latencies, 50) * 1000),
            'latency_p90_ms': float(np.percentile(latencies, 90) * 1000),
            'latency_p95_ms': float(np.percentile(latencies, 95) * 1000),
            'latency_mean_ms': float(np.mean(latencies) * 1000),
        }
    
    def measure_throughput(self, model, predict_fn, X_test, batch_size=1000):
        """
        Measure throughput (samples per second)
        
        Args:
            model: The model object
            predict_fn: Function that takes (model, samples) and returns predictions
            X_test: Test data
            batch_size: Number of samples to process
        """
        n = min(batch_size, len(X_test))
        samples = X_test[:n] if isinstance(X_test, list) else X_test.iloc[:n]
        
        print(f"      Measuring throughput on {n} samples...")
        start = time.time()
        _ = predict_fn(model, samples)
        elapsed = time.time() - start
        
        return {
            'throughput_samples_per_sec': float(n / elapsed),
        }