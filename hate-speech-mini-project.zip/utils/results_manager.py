# utils/results_manager.py
import json
import pandas as pd
from pathlib import Path

class ResultsManager:
    """Manage results storage consistently across all models"""
    
    def __init__(self, model_name):
        self.model_name = model_name
        self.results_dir = Path(f"results/{model_name}")
        self.results_dir.mkdir(parents=True, exist_ok=True)
    
    def save_metrics(self, metrics_dict):
        """Save effectiveness metrics"""
        filepath = self.results_dir / "metrics.json"
        with open(filepath, 'w') as f:
            json.dump(metrics_dict, f, indent=2)
        print(f"      Metrics saved: {filepath}")
    
    def save_efficiency(self, efficiency_dict):
        """Save efficiency metrics"""
        filepath = self.results_dir / "efficiency.json"
        with open(filepath, 'w') as f:
            json.dump(efficiency_dict, f, indent=2)
        print(f"      Efficiency saved: {filepath}")
    
    def save_predictions(self, y_true, y_pred, y_proba=None):
        """Save predictions for statistical testing"""
        df = pd.DataFrame({
            'y_true': y_true,
            'y_pred': y_pred
        })
        if y_proba is not None:
            df['y_proba_class_1'] = y_proba
        
        filepath = self.results_dir / "predictions.csv"
        df.to_csv(filepath, index=False)
        print(f"      Predictions saved: {filepath}")
    
    def save_training_log(self, log_dict):
        """Save training configuration and hyperparameters"""
        filepath = self.results_dir / "training_log.json"
        with open(filepath, 'w') as f:
            json.dump(log_dict, f, indent=2)