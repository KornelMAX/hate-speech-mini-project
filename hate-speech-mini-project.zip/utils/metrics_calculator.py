# utils/metrics_calculator.py
import numpy as np
from sklearn.metrics import (
    precision_recall_fscore_support,
    confusion_matrix,
    matthews_corrcoef,
    average_precision_score,
    brier_score_loss
)

def compute_all_metrics(y_true, y_pred, y_proba=None):
    """
    Compute all effectiveness metrics consistently
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        y_proba: Predicted probabilities for class 1 (optional)
    
    Returns:
        Dictionary of metrics
    """
    
    # Macro-averaged metrics
    precision_macro, recall_macro, f1_macro, _ = precision_recall_fscore_support(
        y_true, y_pred, average='macro', zero_division=0
    )
    
    # Per-class metrics
    precision_per_class, recall_per_class, f1_per_class, _ = precision_recall_fscore_support(
        y_true, y_pred, average=None, zero_division=0
    )
    
    # Weighted metrics (for reference)
    precision_weighted, recall_weighted, f1_weighted, _ = precision_recall_fscore_support(
        y_true, y_pred, average='weighted', zero_division=0
    )
    
    # Confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
    
    metrics = {
        # Macro metrics
        'precision_macro': float(precision_macro),
        'recall_macro': float(recall_macro),
        'f1_macro': float(f1_macro),
        
        # Weighted metrics
        'precision_weighted': float(precision_weighted),
        'recall_weighted': float(recall_weighted),
        'f1_weighted': float(f1_weighted),
        
        # Hate class (class 1) metrics
        'precision_hate': float(precision_per_class[1]) if len(precision_per_class) > 1 else 0.0,
        'recall_hate': float(recall_per_class[1]) if len(recall_per_class) > 1 else 0.0,
        'f1_hate': float(f1_per_class[1]) if len(f1_per_class) > 1 else 0.0,
        
        # Non-hate class (class 0) metrics
        'precision_nonhate': float(precision_per_class[0]),
        'recall_nonhate': float(recall_per_class[0]),
        'f1_nonhate': float(f1_per_class[0]),
        
        # Other metrics
        'mcc': float(matthews_corrcoef(y_true, y_pred)),
        'accuracy': float((tp + tn) / (tp + tn + fp + fn)) if (tp + tn + fp + fn) > 0 else 0.0,
        
        # Confusion matrix
        'tn': int(tn),
        'fp': int(fp),
        'fn': int(fn),
        'tp': int(tp),
    }
    
    # Probability-based metrics (if available)
    if y_proba is not None:
        metrics['pr_auc'] = float(average_precision_score(y_true, y_proba))
        metrics['brier_score'] = float(brier_score_loss(y_true, y_proba))
    
    return metrics